import tkinter as tk
from tkinter import filedialog, messagebox
from textblob import TextBlob
import fitz
from pptx import Presentation
from docx import Document

# Function to analyze sentiment using TextBlob
def analyze_sentiment(text):
    blob = TextBlob(text)
    sentiment = blob.sentiment.polarity
    if sentiment > 0:
        return "Positive Content."
    elif sentiment < 0:
        return "Negative Content."
    else:
        return "Neutral Content."

# Function to handle analyze button click event
def on_analyze():
    text = textbox.get("1.0", tk.END).strip()
    if text:
        sentiment = analyze_sentiment(text)
        res_leb.config(text=f"Sentiment: {sentiment}")
    else:
        messagebox.showwarning("Input Error", "Please enter some text to analyze.")

# Function to handle reset button click event
def on_reset():
    textbox.delete("1.0", tk.END)
    res_leb.config(text="Sentiment: ")

# Function to handle file selection and reading
def on_open_file():
    file_path = filedialog.askopenfilename(filetypes=[("PDF files", "*.pdf"), ("PPTX files", "*.pptx"), ("DOCX files", "*.docx")])
    if file_path:
        print(f"Selected file: {file_path}")
        text = read_file(file_path)
        if text:
            textbox.delete("1.0", tk.END)
            textbox.insert(tk.END, text)
        else:
            messagebox.showwarning("File Error", "Failed to read the file content.")

# Function to read content from PDF, PPTX, and DOCX files
def read_file(file_path):
    if file_path.endswith(".pdf"):
        return read_pdf(file_path)
    elif file_path.endswith(".pptx"):
        return read_pptx(file_path)
    elif file_path.endswith(".docx"):
        return read_docx(file_path)
    else:
        return None

def read_pdf(file_path):
    try:
        doc = fitz.open(file_path)
        text = ""
        for page in doc:
            text += page.get_text()
        return text
    except Exception as e:
        print(f"Error reading PDF: {e}")
        return None

def read_pptx(file_path):
    try:
        prs = Presentation(file_path)
        text = ""
        for slide in prs.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text"):
                    text += shape.text + "\n"
        return text
    except Exception as e:
        print(f"Error reading PPTX: {e}")
        return None

def read_docx(file_path):
    try:
        print(f"Attempting to read DOCX file at: {file_path}")
        doc = Document(file_path)
        text = ""
        for para in doc.paragraphs:
            text += para.text + "\n"
        return text
    except Exception as e:
        print(f"Error reading DOCX: {e}")
        return None

# Set up the main application window
root = tk.Tk()
root.title("Sentiment Analysis Tool")

textbox = tk.Text(root, height=20, width=100)
textbox.pack(pady=10)

button_frame = tk.Frame(root)
button_frame.pack(pady=5)

analyze_button = tk.Button(button_frame, text="Analyze Sentiment", command=on_analyze)
analyze_button.pack(side=tk.LEFT, padx=5)

reset_button = tk.Button(button_frame, text="Reset", command=on_reset)
reset_button.pack(side=tk.LEFT, padx=5)

openfilebutton = tk.Button(button_frame, text="Open File", command=on_open_file)
openfilebutton.pack(side=tk.LEFT, padx=5)

res_leb = tk.Label(root, text="Sentiment: ", font=('Helvetica', 14))
res_leb.pack(pady=10)

root.mainloop()
